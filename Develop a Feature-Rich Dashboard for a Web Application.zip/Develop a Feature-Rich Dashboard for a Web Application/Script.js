document.addEventListener("DOMContentLoaded", () => {
    console.log("Dashboard Loaded Successfully");

    // Set fixed width and height for all charts
    function setChartSize(canvasId) {
        const canvas = document.getElementById(canvasId);
        canvas.style.width = "9.3cm";
        canvas.style.height = "10cm";
        canvas.width = 300;  // 20cm in pixels (approx.)
        canvas.height = 252; // 15cm in pixels (approx.)
    }

    setChartSize("chart1C");
    setChartSize("chart2");
    setChartSize("chart3");

    // Revenue Chart
    const ctx1 = document.getElementById('chart1C').getContext('2d');
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: ['January', 'February', 'March', 'April', 'May', 'June'], 
            datasets: [{
                label: 'Revenue (₹)',
                data: [12000, 19000, 3000, 5000, 2000, 3000],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Sales Chart
    const ctx2 = document.getElementById('chart2').getContext('2d');
    new Chart(ctx2, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'Sales (₹)',
                data: [10000, 15000, 9000, 12000, 6000, 14000],
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 2,
                fill: false
            }]
        },
        options: {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Clickable Data Chart (Pie Chart)
    const ctx3 = document.getElementById("chart3").getContext("2d");
    new Chart(ctx3, {
        type: 'pie',
        data: {
            labels: ['Product A', 'Product B', 'Product C', 'Product D'],
            datasets: [{
                label: 'Market Share',
                data: [20, 30, 25, 25],
                backgroundColor: ['red', 'blue', 'green', 'yellow']
            }]
        },
        options: {
            responsive: false,
            maintainAspectRatio: false
        }
    });

    // Click event for chart3 (Redirects to Dashboard)
    document.getElementById("chart3").addEventListener("click", () => {
        window.location.href = "#Dashboard";
    });
});
